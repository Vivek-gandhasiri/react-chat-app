<h3>This is a chat application made by using React.js and Socket.io</h3>
